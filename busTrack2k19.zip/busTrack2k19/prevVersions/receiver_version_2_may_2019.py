#!/usr/bin/env python
import argparse
import signal
import sys
import time
import pymysql
import ast
import json
import datetime
import ConfigParser

import serial
from datetime import datetime


rfdevice = None



tagData = {

    # "91248c":("1","IN"),
    # "912494":("1","OUT"),
    # "912496":("2","IN"),
    # "912758":("2","OUT"),
    # "9124b7":("3","IN"),
    # "912497":("3","OUT"),
    # "9124ad":("4","IN"),
    # "9124ab":("4","OUT"),
    # "9124a8":("5","IN"),
    # "9124b6":("5","OUT"),
    # "912757":("","IN"),   
    # "90f303":("","OUT"),
    # "9124b1":("","IN"),
    # "912756":("","OUT"),
    # "9124a2":("","IN"),
    # "9124b0":("","OUT"),
    # "91249c":("","IN"),
    # "9124a0":("","OUT"),
    # "9124af":("","IN"),
    # "91275a":("","OUT"),
    # "912755":("","IN"),
    # "912495":("","OUT"),
    # "9124aa":("","IN"),
    # "91275b":("","OUT"),
    # "9124a4":("","IN"),
    # "9124ac":("","OUT"),
    # "9124a9":("","IN"),   
    # "9124a1":("","OUT"),
    # "912754":("","IN"),
    # "91248d":("","OUT"),
    "9124ae":("218","IN"),
    "9124a5":("218","OUT"),
    "9124b2":("230","IN"),
    "9124a3":("230","OUT"),
    "912498":("211","IN"),
    "912492":("211","OUT"),
    "91249b":("207","IN"),
    "91249d":("207","OUT"),
    "9124a6":("469","IN"),
    "91248b":("469","OUT"),
    "9124ac":("8""IN"),
    "912757":("8","OUT"),
}


class MySql:
    def __init__(self):
        filename = "/home/pi/busTrack2k19/config.ini"        
        self.cf = ConfigParser.ConfigParser()
        self.cf.read(filename)
    def connect(self):        
        dbHost = self.cf.get("Mysql","host")                                           # MYSQL DETAILS
        dbPort = int(self.cf.get("Mysql","port"))
        dbUser = self.cf.get("Mysql","user")
        dbPassword = self.cf.get("Mysql","password")
        database = self.cf.get("Mysql","database")
        self.table = self.cf.get("Mysql","table")      
        self.db = pymysql.connect(dbHost,dbUser,dbPassword,database)                   # Open database connection       
        self.cursor = self.db.cursor()           
    def push(self,fields,values):
        sqlQuery = "INSERT INTO "+self.table+""
        sqlQuery += "("
        for field in fields:
            sqlQuery+=str(field)+","
        sqlQuery = sqlQuery[:-1]    
        sqlQuery+=") VALUES ("    

        for value in values:
            sqlQuery+=value+","
        sqlQuery = sqlQuery[:-1]    

        sqlQuery+=");"

        print sqlQuery

        try:
            
            self.cursor.execute(sqlQuery)
            self.db.commit()
            print "\n successfully inserted ....\n "
#            else:
#                print " reconnect to database\n"
#                self.connect()
        except Exception as e:
            print e,"exception"
            self.db.rollback()
class Rf:    
    def __init__(self,mysqlObj):
        self.ser = serial.Serial('/dev/ttyUSB0',baudrate=9600)
        self.tag = ""
        self.mysqlObj = mysqlObj
        print self.mysqlObj

    def serialRead(self):
        print "Serial Reading...."
        cardNo = ""
        while True:
            try:
                n = self.ser.inWaiting()
                if n != 0:
                    data = str(self.ser.read(n))
                    
                    print (data),"DATA"
                    print(len(data))
                    cardNo+=data
                    print (cardNo),"CARD NO"

                    if (cardNo in tagData.keys()):
                        print cardNo,"complete tag ID\n"
                        values = ["'"+str(tagData[cardNo[:6]][0])+"'","'"+str(cardNo[:6])+"'","'"+str(tagData[cardNo[:6]][1])+"'","'"+str(datetime.now().replace(microsecond=0))+"'"]
                        fields = ["busNo","tagNo","status","dateTime"]
                        print (values," = ",fields)
                        self.mysqlObj.push(fields,values)
                        cardNo = ""
                        
            except KeyboardInterrupt as e:
                self.ser.close() # closes the serial connection
                sys.exit() # closes the program
if __name__ == '__main__':
    m = MySql()
    m.connect()
    rf = Rf(m)
    rf.serialRead()



