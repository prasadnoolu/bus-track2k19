'''

    BusTrack program 
    Edited By - Rajeev Brahma
    Version change objectives - 
                1) Changed the database to local database
                2) Added 240 bus details

'''

#!/usr/bin/env python

import signal
import sys
import time
import MySQLdb
import logging
import ast
import json
import datetime
import ConfigParser
import serial
from datetime import datetime
import csv
rfdevice = None

LOG_FILENAME = '/home/pi/busTrack2k19/LogFiles/receiver'+str(datetime.now().replace(microsecond=0,second=0))+'.log'
logging.basicConfig(filename=LOG_FILENAME,level=logging.DEBUG,format='%(asctime)s, %(levelname)s, %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

columns = ["busNo","tagNo","status","dateTime"]
    

tagData = {
   
    "9124ae":("218","IN"),
    "9124a5":("218","OUT"),
    "9124b2":("230","IN"),
    "9124a3":("230","OUT"),
    "9124a8":("211","OUT"),
    "912492":("211","IN"),
    "91249b":("207","IN"),
    "91249d":("207","OUT"),
    "9124a6":("469","IN"),
    "91248b":("469","OUT"),
    "912754":("240","IN"),
    "91248d":("240","OUT"),
    "9124ac":("TEST","IN"),
    "912757":("TEST","OUT"),
    "9124a0":("TEST2","IN"),
    "91275a":("TEST2","OUT"),
    
}


class MySql:
    def __init__(self):
        filename = "/home/pi/busTrack2k19/config.ini"        
        self.cf = ConfigParser.ConfigParser()
        self.cf.read(filename)
    def connect(self):        
        try:
            dbHost = self.cf.get("Mysql","host")                                           # MYSQL DETAILS
            dbPort = int(self.cf.get("Mysql","port"))
            dbUser = self.cf.get("Mysql","user")
            dbPassword = self.cf.get("Mysql","password")
            database = self.cf.get("Mysql","database")
            self.table = self.cf.get("Mysql","table")      
            self.db = MySQLdb.connect(dbHost,dbUser,dbPassword,database)                   # Open database connection       
            self.cursor = self.db.cursor()           
        except Exception as e:
            logging.error("Mysql connect Error - %s,' - ',%s"%(e,type(e)))

    def push(self,fields,values):
        sqlQuery = "INSERT INTO "+self.table+""
        sqlQuery += "("
        for field in fields:
            sqlQuery+=str(field)+","
        sqlQuery = sqlQuery[:-1]    
        sqlQuery+=") VALUES ("    

        for value in values:
            sqlQuery+=value+","
        sqlQuery = sqlQuery[:-1]    

        sqlQuery+=");"

        print sqlQuery

        try:

             self.cursor.execute(sqlQuery)
             self.db.commit()
             print "\n successfully inserted ....\n "    
        except (AttributeError,MySQLdb.OperationalError):
            print 'reconnect'
            st=time.time()
            logging.info("Mysql  Lost Connection ")
            self.connect()
            self.cursor.execute(sqlQuery)
            self.db.commit()
            t = str(time.time()-st)
            logging.info("Mysql Reinsert Success & %s Taken to reconnect"%(t))
        except Exception as e:
            logging.error("Mysql  Error - %s,' - ',%s"%(e,type(e)))
            with open("BackupData.xlsx",mode = 'w') as bData: 
                bDataWriter = csv.DictWriter(bData,fieldnames=columns)
                bData.writerow({fields[0]:values[0],fields[1]:values[1],fields[2]:values[2],fields[3]:values[3]})
            bData.close()    



class Rf:    
    def __init__(self,mysqlObj):
        self.ser = serial.Serial('/dev/ttyUSB0',baudrate=9600)
        self.tag = ""
        self.mysqlObj = mysqlObj
        print self.mysqlObj

    def serialRead(self):
        print "Serial Reading...."
        cardNo = ""
        sent = 0
        donereading = 0
        while True:
            try:
                n = self.ser.inWaiting()
                if n != 0:
                    data = str(self.ser.read(n))
                    print (data),"DATA"
                    cardNo+=data
                    print (cardNo),"CARD NO"

                    if (cardNo in tagData.keys()):
                        print cardNo,"complete tag ID\n"
                        values = ["'"+str(tagData[cardNo[:6]][0])+"'","'"+str(cardNo[:6])+"'","'"+str(tagData[cardNo[:6]][1])+"'","'"+str(datetime.now().replace(microsecond=0))+"'"]
                        fields = ["busNo","tagNo","status","dateTime"]
                        self.mysqlObj.push(fields,values)
                        cardNo = ""
                    elif(len(cardNo)>6):
                        cardNo = ""
                    else:
                        logging.info("New Tag Detected %s"%(cardNo))
                        cardNo = ""        


                                 
            except KeyboardInterrupt as e:
                logging.error("Serial Read Error - %s,' - ',%s"%(e,type(e)))
                logging.error(" ************ PROGRAM TERMINATED ************** ")
                self.ser.close() # closes the serial connection
                sys.exit() # closes the program
if __name__ == '__main__':
    
    with open("BackupData.xlsx",mode = 'w') as bData: 
        bDataWriter = csv.DictWriter(bData,fieldnames=columns)
        bDataWriter.writeheader()
    bData.close()
    m = MySql()
    m.connect()
    rf = Rf(m)
    rf.serialRead()



