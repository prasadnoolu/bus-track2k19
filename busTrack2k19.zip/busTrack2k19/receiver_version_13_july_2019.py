'''

    BusTrack program 
    Edited By - Thub
    Version change objectives - 
                1) New Buses - 108,432,115,411 
                2) Added logging info at existing card detection and after successfull insert.
                3) Modified the name of the receiver log, initialized the log file in append mode.                
'''             

#!/usr/bin/env python

import signal
import sys
import time
import MySQLdb
import logging
import ast
import json
import datetime
import ConfigParser
import serial
from datetime import datetime
import csv
import requests
rfdevice = None

LOG_FILENAME = '/home/pi/Desktop/busTrack2k19/LogFiles/receiver.log'
logging.basicConfig(filename=LOG_FILENAME,filemode = 'a',level=logging.DEBUG,format='%(asctime)s, %(levelname)s, %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

columns = ["busNo","tagNo","status","dateTime"]
    

tagData = {
   
    "9124ae":("218","IN"),
    "9124a5":("218","OUT"),
    "9124b2":("230","IN"),
    "9124a3":("230","OUT"),
    "9124a8":("211","OUT"),
    "912492":("211","IN"),
    "91249b":("207","IN"),
    "91249d":("207","OUT"),
    "9124a6":("241","IN"),
    "91248b":("241","OUT"),
    "912754":("240","IN"),
    "91248d":("240","OUT"),
    "912496":("431","IN"),
    "91249f":("431","OUT"),
    "912497":("435","IN"),
    "9124a9":("435","OUT"),
    "91248c":("437","IN"),
    "9124b0":("437","OUT"),
    "91249c":("443","IN"),
    "912494":("443","OUT"),
    #"9124a1":("458","IN"),Missed
    "90f2dc":("458","IN"),
    "9124a2":("458","OUT"),
    "9124b6":("118","IN"),
    "912758":("118","OUT"),
    "9124ac":("411","OUT"),
    "9124af":("411","IN"),
    "9124b1":("108","IN"),
    "912756":("108","OUT"),
    "9124a0":("432","OUT"),
    "9124b7":("432","IN"),
    "91275a":("115","IN"),
    "912753":("115","OUT"),
   #"9124a7":("132","IN"),
   #"912798":("132","OUT"),
    "9124b5":("429","IN"),
    "912752":("429","OUT"),
    #"912495":("425","IN"), not using
    #"9124a4":("425","OUT"),not using
    "9124ad":("456","IN"),
    "90f303":("456","OUT"),
    "91275b":("457","IN"),
    "912757":("457","OUT"),
    "91249a":("131","IN"),
    "912759":("131","OUT"),
    "90f304":("123","IN"),
    "9124ab":("123","OUT"),
    "9124b4":("473","IN"),
    "912755":("473","OUT"),
    "9124aa":("122","IN"),
    "912499":("122","OUT"),
    "93a782":("101", "IN"),
    "93a783":("101","OUT"),
    "93a77b":("102","IN"),
    "93a77c":("102","OUT"),
    "93a774":("103","IN"),
    "93a7bd":("103","OUT"),
    "93a76a":("104","IN"),
    "90f2f7":("104","OUT"),
    #"93a76b":("104","OUT"),Missed
    "93a7b9":("105","IN"),
    "93a7ba":("105","OUT"),
    "93a64d":("106","IN"),
    #"93a7a5":("106","IN"), Missed
    "93a7c7":("106","OUT"),
    "93a7a6":("107","IN"),
    "90f2f8":("107","OUT"),
    #"93a7a8":("107","OUT"), Missed
    "9124b1":("108","IN"),
    "912756":("108","OUT"),
    "93a5d5":("109","IN"),
    "93a5d6":("109","OUT"),
    "93a780":("110","IN"),
    "93a781":("110","OUT"),
    "93a76c":("111","IN"),
    "93a76d":("111","OUT"),
    "93a779":("112","IN"),
    "93a77a":("112","OUT"),
    "93a65d":("113","IN"),
    "93a669":("113","OUT"),
    "93a65b":("114","IN"),
    "93a65c":("114","OUT"),
    "91275a":("115","IN"),
    "912753":("115","OUT"),
    "93a699":("116","IN"),
    "93a69a":("116","OUT"),
    "93a766":("117","IN"),
    "93a767":("117","OUT"),
    "9124b6":("118","IN"),
    "912758":("118","OUT"),
    "93a5fd":("119","IN"),
    "93a5fc":("119","OUT"),
    "93a777":("120","IN"),
    "93a778":("120","OUT"),
    "93a5ff":("121","IN"),
    "93a5fe":("121","OUT"),
    "9124aa":("122","IN"),
    "912499":("122","OUT"),
    "90f304":("123","IN"),
    "9124ab":("123","OUT"),
    "93a77e":("125","IN"),
    "93a77f":("125","OUT"),
    "93a7c6":("126","IN"),
    "93a7c8":("126","OUT"),
    "93a772":("127","IN"),
    "93a773":("127","OUT"),
    "93a7bb":("128","IN"),
    "93a7be":("128","OUT"),
    "93a7c5":("129","IN"),
    "93a77d":("129","OUT"),
    "93a7bf":("130","IN"),
    "93a7c1":("130","OUT"),
    "91249a":("131","IN"),
    "912759":("131","OUT"),
    "9124a7":("132","IN"),
    "912498":("132","OUT"),
    "93a639":("133","IN"),
    "93a698":("133","OUT"),
    "90f2f9":("134","IN"),
    "90f2fd":("134","OUT"),
    "93a784":("135","IN"),
    "93a785":("135","OUT"),
    "93a61e":("136","IN"),
    "93a61f":("136","OUT"),
    "93a768":("137","IN"),
    "93a769":("137","OUT"),
    "93a775":("139","IN"),
    "93a776":("139","OUT"),
    "93a770":("140","IN"),
    "93a771":("140","OUT"),
    "93a7a1":("142","IN"),
    "93a7b7":("142","OUT"),
    "93a76e":("143","IN"),
    "93a76f":("143","OUT"),
    "93a7a3":("144","IN"),
    "93a7a4":("144","OUT"),
    "93a63a":("145","IN"),
    "93a63b":("145","OUT"),
    "93a7a2":("146","IN"),
    "93a7b8":("146","OUT"),
    "93a7a0":("147","IN"),
    "93a7c0":("147","OUT"),
    "93a634":("203","IN"),
    "93a635":("203","OUT"),
    "91e6ca":("204","IN"),
    "91e6c9":("204","OUT"),
    "9124a4":("205","IN"),
    "93a679":("205","OUT"),
    "93a7aa":("206","IN"),
    "93a7af":("206","OUT"),
    "91249b":("207","IN"),
    "91249d":("207","OUT"),
    "93a788":("208","IN"),
    "93a789":("208","OUT"),
    "93a78c":("208s","IN"),
    "93a78d":("208s","OUT"),
    "93a648":("209","IN"),
    "93a64a":("209","OUT"),
    "93a78a":("210","IN"),
    "93a78b":("210","OUT"),
    "912492":("211","IN"),
    "9124a8":("211","OUT"),
    "93a677":("212","IN"),
    "93a678":("212","OUT"),
    "93a632":("213","IN"),
    "93a633":("213","OUT"),
    "93a667":("214","IN"),
    "93a668":("214","OUT"),
    "93a624":("215","IN"),
    "93a625":("215","OUT"),
    "93a636":("216","IN"),
    "93a637":("216","OUT"),
    "93a62e":("217","IN"),
    "93a62f":("217","OUT"),
    "9124ae":("218","IN"),
    "9124a5":("218","OUT"),
    "93a62a":("124","IN"),
    "93a62b":("124","OUT"),
    "93a7b3":("219","IN"),
    "93a7b4":("219","OUT"),
    "93a62c":("220","IN"),
    "93a62d":("220","OUT"),
    "93a675":("221","IN"),
    "93a676":("221","OUT"),
    "93a796":("222","IN"),
    "93a797":("222","OUT"),
    "93a630":("223","IN"),
    "93a631":("223","OUT"),
    "93a794":("224","IN"),
    "93a795":("224","OUT"),
    "93a792":("225","IN"),
    "93a793":("225","OUT"),
    "93a627":("226","IN"),
    "93a629":("226","OUT"),
    "93a647":("227","IN"),
    "93a649":("227","OUT"),
    "93a7b2":("228","IN"),
    "93a79d":("228","OUT"),
    "93a78e":("229","IN"),
    "93a78f":("229","OUT"),
    "9124a3":("230","OUT"),
    "93a670":("230","IN"),
    "93a66a":("231","IN"),
    "93a67c":("231","OUT"),
    "93a66b":("232","IN"),
    "93a66d":("232","OUT"),
    "93a798":("233","IN"),
    "93a799":("233","OUT"),
    "93a7b0":("234","IN"),
    "93a7b1":("234","OUT"),
    "93a673":("235","IN"),
    "93a674":("235","OUT"),
    "93a66e":("237","IN"),
    "93a66f":("237","OUT"),
    "93a626":("238","IN"),
    "93a628":("238","OUT"),
    "93a790":("239","IN"),
    "93a791":("239","OUT"),
    "912754":("240","IN"),
    "91248d":("240","OUT"),
    "9124a6":("241","IN"),
    "91248b":("241","OUT"),
    "93a60b":("242","IN"),
    "93a60c":("242","OUT"),
    "93a63c":("243","IN"),
    "93a63d":("243","OUT"),
    "93a600":("244","IN"),
    "93a601":("244","OUT"),
    "93a606":("301","IN"),
    "93a607":("301","OUT"),
    "91e6bc":("302","IN"),
    "91e6be":("302","OUT"),
    "93a79a":("304","IN"),
    "93a602":("304","OUT"),
    "93a697":("306","IN"),
    "93a63e":("306","OUT"),
    "93a614":("307","IN"),
    "93a615":("307","OUT"),
    "93a612":("308","IN"),
    "93a613":("308","OUT"),
    "93a640":("309","IN"),
    "93a641":("309","OUT"),
    "93a645":("310","IN"),
    "93a646":("310","OUT"),
    "93a608":("311","IN"),
    "93a609":("311","OUT"),
    "93a643":("313","IN"),
    "93a644":("313","OUT"),
    "93a79b":("314","IN"),
    "93a79c":("314","OUT"),
    "93a63f":("315","IN"),
    "93a642":("315","OUT"),
    "93a604":("316","IN"),
    "90f301":("316","OUT"),
    #"93a605":("316","OUT"),MIssed
    "93a69b":("401","IN"),
    "93a65a":("401","OUT"),
    "93a663":("402","IN"),
    "93a696":("402","OUT"),
    "93a672":("403","IN"),
    "93a671":("403","OUT"),
    "93a68f":("404","IN"),
    "93a691":("404","OUT"),
    "93a683":("405","IN"),
    "93a684":("405","OUT"),
    "93a692":("406","IN"),
    "93a693":("406","OUT"),
    "93a5db":("407","IN"),
    "93a5dc":("407","OUT"),
    "93a68a":("408","IN"),
    "93a68c":("408","OUT"),
    "93a617":("409","IN"),
    "93a618":("409","OUT"),
    "93a620":("410","IN"),
    "93a621":("410","OUT"),
    "9124ac":("411","OUT"),
    "9124af":("411","IN"),
    "93a65e":("412","IN"),
    "93a65f":("412","OUT"),
    #"93a661":("413","IN"),Missed
    "93a9ba":("413","IN"),
    "93a662":("413","OUT"),
    "93a5dd":("414","IN"),
    "93a5de":("414","OUT"),
    "93a658":("415","IN"),
    "93a659":("415","OUT"),
    "93a7a7":("416","IN"),
    "93a7a9":("416","OUT"),
    "93a686":("417","IN"),
    "93a689":("417","OUT"),
    "93a60d":("418","IN"),
    "93a60e":("418","OUT"),
    "93a654":("419","IN"),
    "93a67a":("419","OUT"),
    "93a5fa":("420","IN"),
    "93a5fb":("420","OUT"),
    "93a5e9":("421","IN"),
    "93a5f0":("421","OUT"),
    "93a66c":("422","IN"),
    "93a656":("422","OUT"),
    "93a79e":("423","IN"),
    "93a79f":("423","OUT"),
    "93a7c2":("424","IN"),
    "93a7c3":("424","OUT"),
    "93a7c4":("425","IN"),
    "93a7bc":("425","OUT"),
    "93a651":("426","IN"),
    "93a657":("426","OUT"),
    "93a5f7":("427","IN"),
    "93a5f8":("427","OUT"),
    "93a5e5":("428","IN"),
    "93a5e6":("428","OUT"),
    "9124b5":("429","IN"),
    "912752":("429","OUT"),
    "93a5ea":("430","IN"),
    "93a5eb":("430","OUT"),
    "912496":("431","IN"),
    "91249f":("431","OUT"),
    "9124a0":("432","OUT"),
    "9124b7":("432","IN"),
    "93a680":("433","IN"),
    "93a67f":("433","OUT"),
    "93a616":("434","IN"),
    "93a60a":("434","OUT"),
    "912497":("435","IN"),
    "9124a9":("435","OUT"),
    "93a5f5":("436","IN"),
    "93a5f6":("436","OUT"),
    "91248c":("437","IN"),
    "9124b0":("437","OUT"),
    "93a7ad":("438","IN"),
    "93a7ae":("438","OUT"),
    "93a5e7":("439","IN"),
    "93a5e8":("439","OUT"),
    "93a7ab":("440","IN"),
    "93a7ac":("440","OUT"),
    "93a7b5":("441","IN"),
    "93a7b6":("441","OUT"),
    "93a5f3":("442","IN"),
    "93a5f4":("442","OUT"),
    "91249c":("443","IN"),
    "912494":("443","OUT"),
    "93a61c":("444","IN"),
    "93a61d":("444","OUT"),
    "93a685":("445","IN"),
    "93a688":("445","OUT"),
    "93a622":("446","IN"),
    "93a623":("446","OUT"),
    "93a5ec":("447","IN"),
    "93a5ed":("447","OUT"),
    "93a660":("448","IN"),
    "93a666":("448","OUT"),
    "93a664":("449","IN"),
    "93a665":("449","OUT"),
    "93a5e1":("450","IN"),
    "93a5e2":("450","OUT"),
    "93a67d":("451","IN"),
    "93a67e":("451","OUT"),
    "93a603":("453","IN"),
    "93a638":("453","OUT"),
    "93a5df":("454","IN"),
    "93a5e0":("454","OUT"),
    "93a5f1":("455","IN"),
    "93a5f2":("455","OUT"),
    "9124ad":("456","IN"),
    "90f303":("456","OUT"),
    #"93a786":("456","IN"),
    #"93a787":("456","OUT"),
    "91275b":("457","IN"),
    "912757":("457","OUT"),
    "9124a1":("458","IN"),
    "9124a2":("458","OUT"),
    "93a5d9":("459","IN"),
    "93a5da":("459","OUT"),
    "93a681":("460","IN"),
    "93a682":("460","OUT"),
    "93a610":("461","IN"),
    "93a611":("461","OUT"),
    "93a69c":("462","IN"),
    "93a68b":("462","OUT"),
    "93a68e":("464","IN"),
    "93a690":("464","OUT"),
    "93a5ee":("465","IN"),
    "93a5ef":("465","OUT"),
    "93a694":("466","IN"),
    "93a695":("466","OUT"),
    "93a61a":("467","IN"),
    "93a61b":("467","OUT"),
    "93a5d7":("468","IN"),
    "93a5d8":("468","OUT"),
    "93a5e3":("470","IN"),
    "93a5e4":("470","OUT"),
    "93a687":("471","IN"),
    "93a68d":("471","OUT"),
    "93a619":("472","IN"),
    "93a60f":("472","OUT"),
    "9124b4":("473","IN"),
    "912755":("473","OUT"),
    "93a653":("452","OUT"),
    "93a655":("452","IN"),
    "93a64e":("303","IN"),
    "93a64f":("303","OUT"),
    "93a650":("305","IN"),
    "93a652":("305","OUT"),
    "93a64b":("201","IN"),
    "93a64c":("201","OUT"),
    "93a786":("test","IN"),
    "93a787":("test","OUT"),
    

}


class MySql:
    def __init__(self):
        filename = "/home/pi/busTrack2k19/config.ini"        
        self.cf = ConfigParser.ConfigParser()
        self.cf.read(filename)
    def connect(self):        
        try:
            dbHost = self.cf.get("Mysql","host")                                           # MYSQL DETAILS
            dbPort = int(self.cf.get("Mysql","port"))
            dbUser = self.cf.get("Mysql","user")
            dbPassword = self.cf.get("Mysql","password")
            database = self.cf.get("Mysql","database")
            self.table = self.cf.get("Mysql","table")      
            self.db = MySQLdb.connect(dbHost,dbUser,dbPassword,database)                   # Open database connection       
            self.cursor = self.db.cursor()           
        except Exception as e:
            logging.error("Mysql connect Error - %s,' - ',%s"%(e,type(e)))

    def push(self,fields,values):
        sqlQuery = "INSERT INTO "+self.table+""
        sqlQuery += "("
        for field in fields:
            sqlQuery+=str(field)+","
        sqlQuery = sqlQuery[:-1]    
        sqlQuery+=") VALUES ("    

        for value in values:
            sqlQuery+=value+","
        sqlQuery = sqlQuery[:-1]    

        sqlQuery+=");"

        print sqlQuery

        try:

             self.cursor.execute(sqlQuery)
             self.db.commit()
             logging.info("INSERTED")    
        except (AttributeError,MySQLdb.OperationalError):
            print 'reconnect'
            st=time.time()
            logging.info("Mysql  Lost Connection ")
            self.connect()
            self.cursor.execute(sqlQuery)
            self.db.commit()
            t = str(time.time()-st)
            logging.info("Mysql Reinsert Success & %s Taken to reconnect"%(t))
        except Exception as e:
            logging.error("Mysql  Error - %s,' - ',%s"%(e,type(e)))
            with open("BackupData.xlsx",mode = 'w') as bData: 
                bDataWriter = csv.DictWriter(bData,fieldnames=columns)
                bData.writerow({fields[0]:values[0],fields[1]:values[1],fields[2]:values[2],fields[3]:values[3]})
            bData.close()    



class Rf:    
    def __init__(self,mysqlObj):
        self.ser = serial.Serial('/dev/ttyUSB0',baudrate=9600)
        self.tag = ""
        self.mysqlObj = mysqlObj
        print self.mysqlObj

    def serialRead(self):
        print "Serial Reading...."
        logging.info("Serial Reading...")
        cardNo = ""
        sent = 0
        donereading = 0
        while True:
            try:
                n = self.ser.inWaiting()
                if n != 0:
                    data = str(self.ser.read(n))
                    cardNo+=data
                    logging.info("Detected CARD NO  - %s"%(cardNo))
                    print cardNo
                    if (cardNo[:6] in tagData.keys()):
                        print cardNo
                        logging.info ("CARD NO Existed  - %s"%(cardNo))
                        values = ["'"+str(tagData[cardNo[:6]][0])+"'","'"+str(cardNo[:6])+"'","'"+str(tagData[cardNo[:6]][1])+"'","'"+str(datetime.now().replace(microsecond=0))+"'"]
                        fields = ["busNo","tagNo","status","dateTime"]
                        self.mysqlObj.push(fields,values)
                        serv_url="http://172.7.91.249:2222/bus/"
                        bustag=str(cardNo[:6])
                        servurl=serv_url+bustag
                        logging.info ("server url  - %s"%(servurl))
                        print servurl
                        try:
                           response_status=requests.get(servurl)
                           print response_status
                           response_value=str(response_status)
                           logging.info ("response Value -%s"%(response_value))
                           response_value=response_value[11:14]
                           if response_value=="200":
                               logging.info("The success value - %s"%(str(response_status)))
                           else:
                              loggin.info("Card not inserted into server, Please check the server")
                        
                        except requests.exceptions.RequestException as err:
                            print ("OOps: Something Else",err)
                        except requests.exceptions.HTTPError as errh:
                            print ("Http Error:",errh)
                        except requests.exceptions.ConnectionError as errc:
                            print ("Error Connecting:",errc)
                        except requests.exceptions.Timeout as errt:
                            print ("Timeout Error:",errt)
                        
                                         
                        
                        cardNo = ""
                    elif(len(cardNo)>6):
                        logging.info("Card No is length is -%s"%(str(len(cardNo))))
                        cardNo = ""
                    
                    else:
                        logging.info("Card Not Existed  - %s"%(cardNo))
                        cardNo = ""        


                                 
            except KeyboardInterrupt as e:
                logging.error("Serial Read Error - %s,' - ',%s"%(e,type(e)))
                logging.error(" ************ PROGRAM TERMINATED ************** ")
                print("Serial Read Error - %s,' - ',%s"%(e,type(e)))
                print(" ************ PROGRAM TERMINATED ************** ")
            
                self.ser.close() # closes the serial connection
                sys.exit() # closes the program
                
if __name__ == '__main__':
    logging.info(" \n\n\n ****** PROGRAM STARTED **** \n\n\n ")
    print("\n\n\n ****** PROGRAM STARTED **** \n\n\n ")
    with open("BackupData.xlsx",mode = 'w') as bData: 
        bDataWriter = csv.DictWriter(bData,fieldnames=columns)
        bDataWriter.writeheader()
    bData.close()
    m = MySql()
    m.connect()
    rf = Rf(m)
    rf.serialRead()



