'''

    BusTrack program 
    Edited By - Rajeev Brahma
'''             

#!/usr/bin/env python

import sys
import time
import MySQLdb
import logging
import ast
import json
import datetime
import ConfigParser
from datetime import datetime


LOG_FILENAME = '/home/pi/busTrack2k19/LogFiles/dbUpdate.log'

logging.basicConfig(filename=LOG_FILENAME,filemode = 'a',level=logging.DEBUG,format='%(asctime)s, %(levelname)s, %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

columns = ["busNo","tagNo","status","dateTime"]
    



class MySql:
    def __init__(self,filename):
        self.cf = ConfigParser.ConfigParser()
        self.cf.read(filename)
    def connect(self):        
        try:
            dbHost = self.cf.get("Mysql","host")                                           # MYSQL DETAILS
            dbPort = int(self.cf.get("Mysql","port"))
            dbUser = self.cf.get("Mysql","user")
            dbPassword = self.cf.get("Mysql","password")
            database = self.cf.get("Mysql","database")
            self.table = self.cf.get("Mysql","table")      
            self.db = MySQLdb.connect(dbHost,dbUser,dbPassword,database)                   # Open database connection       
            self.cursor = self.db.cursor()
            return self.cursor           
        except Exception as e:
            logging.error("Mysql connect Error - %s,' - ',%s"%(e,type(e)))

    def push(self,cursor,fields,values):
	self.cursor = cursor
	self.table = "bus_route_slo"
	sqlQuery = "INSERT INTO "+self.table+""
	sqlQuery += "("
	for field in fields:
		sqlQuery+=str(field)+","
	sqlQuery = sqlQuery[:-1]    
		
	sqlQuery+=") VALUES "
	sqlQuery+=values
	sqlQuery+=";"
	print sqlQuery
	try:
		self.cursor.execute(sqlQuery)
             	self.db.commit()
             	logging.info("INSERTED")    
        except (AttributeError,MySQLdb.OperationalError):
            	print 'reconnect'
           	st=time.time()
            	logging.info("Mysql  Lost Connection ")
            	self.connect()
            	self.cursor.execute(sqlQuery)
            	self.db.commit()
            	t = str(time.time()-st)
            	logging.info("Mysql Reinsert Success & %s Taken to reconnect"%(t))
        except Exception as e:
            	logging.error("Mysql  Error - %s,' - ',%s"%(e,type(e)))
            

    def pull(self,cursor):    	
	self.cursor = cursor
	self.value = ''
        try:
			fetchQuery = "SELECT * FROM bus_data WHERE dateTime>="+"'"+str(datetime.now().date())+"'"			
			print fetchQuery
			self.cursor.execute(fetchQuery)
			rows =  self.cursor.fetchall()
			for row in rows:
				self.value+=str(row)
				self.value+=","
			return self.value[:-1]
        except Exception as e:
            logging.error("Mysql Pull Error - %s,' - ',%s"%(e,type(e)))

	                
if __name__ == '__main__':
    logging.info(" \n\n\n ****** PROGRAM STARTED **** \n\n\n ")
    
    filename = "/home/pi/busTrack2k19/config.ini"        
    
    m = MySql(filename)
    cursor = m.connect()
    data = m.pull(cursor)
    print (data)
    filename = "/home/pi/busTrack2k19/mainDBconfig.ini/"
    m2 = MySql(filename)
    cursor2 = m2.connect()
    m2.push(cursor2,columns,data)


