#!/usr/bin/env python
import argparse
import signal
import sys
import time
import MySQLdb
import ast
import json
import datetime
import ConfigParser
# import serial
from datetime import datetime


rfdevice = None




# host:148.72.199.172
# port:3306
# user:rajeev
# password:
# database:gokart2k19
# racetable:raceDetails
# karttable:kartDetails



class MySql:
    def __init__(self):
        filename = "config.ini"        
        self.cf = ConfigParser.ConfigParser()
        self.cf.read(filename)
        self.connect()        
    def connect(self):        
        dbHost = "148.72.199.172"                                           # MYSQL DETAILS                   
        dbPort = 3306
        dbUser = "rajeev"
        dbPassword = "KelHYUY{8aJk"
        database = "gokart2k19"
        self.table = "bus_route_slo"      
        self.db = MySQLdb.connect(dbHost,dbUser,dbPassword,database)                   # Open database connection       
        self.cursor = self.db.cursor()
         
 
    def push(self,fields,values):
        sqlQuery = "INSERT INTO "+self.table+""
        sqlQuery += "("
        for field in fields:
            sqlQuery+=str(field)+","
        sqlQuery = sqlQuery[:-1]    
        sqlQuery+=") VALUES ("    

        for value in values:
            sqlQuery+=value+","
        sqlQuery = sqlQuery[:-1]    
            
        sqlQuery+=");"

        
        try:
            print sqlQuery        
            self.cursor.execute(sqlQuery)
            self.db.commit()
            print 'insert'
        except(AttributeError,MySQLdb.OperationalError):
                print 'reconnect'
                st=time.time()
                self.connect()
                self.cursor.execute(sqlQuery)
                self.db.commit()
                print time.time()-st
                print 'reconnect insert insert'
#        except Exception as e:
#            print e
#            self.db.rollback()
#            print e





if __name__ == '__main__':
    m = MySql()
    while True:
        val = int(raw_input("enter val"))
        if (val == 1): 
            values = ["'"+"010"+"'","'"+"314955"+"'","'"+"TEST"+"'","'"+str(datetime.now().replace(microsecond=0))+"'"]
            fields = ["busNo","tagNo","status","dateTime"]                                    
            m.push(fields,values)

            time.sleep(5)
