'''

    BusTrack program 
    Edited By - Rajeev Brahma
    Version change objectives - 
                1) New Buses - 108,432,115,411 
                2) Added logging info at existing card detection and after successfull insert.
                3) Modified the name of the receiver log, initialized the log file in append mode.                
'''             

#!/usr/bin/env python

import signal
import sys
import time
import MySQLdb
import logging
import ast
import json
import datetime
import ConfigParser
import serial
from datetime import datetime
import csv
rfdevice = None

LOG_FILENAME = '/home/pi/busTrack2k19/LogFiles/receiver.log'
logging.basicConfig(filename=LOG_FILENAME,filemode = 'a',level=logging.DEBUG,format='%(asctime)s, %(levelname)s, %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

columns = ["busNo","tagNo","status","dateTime"]
    

tagData = {
   
    "9124ae":("218","IN"),
    "9124a5":("218","OUT"),
    "9124b2":("230","IN"),
    "9124a3":("230","OUT"),
    "9124a8":("211","OUT"),
    "912492":("211","IN"),
    "91249b":("207","IN"),
    "91249d":("207","OUT"),
    "9124a6":("241","IN"),
    "91248b":("241","OUT"),
    "912754":("240","IN"),
    "91248d":("240","OUT"),
    "912496":("431","IN"),
    "91249f":("431","OUT"),
    "912497":("435","IN"),
    "9124a9":("435","OUT"),
    "91248c":("437","IN"),
    "9124b0":("437","OUT"),
    "91249c":("443","IN"),
    "912494":("443","OUT"),
    "9124a1":("458","IN"),
    "9124a2":("458","OUT"),
    "9124b6":("118","IN"),
    "912758":("118","OUT"),
    "9124ac":("411","OUT"),
    "9124af":("411","IN"),    
    "9124b1":("108","IN"),
    "912756":("108","OUT"),
    
    "9124a0":("432","OUT"),
    "9124b7":("432","IN"),
    
    "91275a":("115","IN"),
    "912753":("115","OUT"),
    "912498":("000","T-IN"),
    "91275b":("000","T-OUT"),

}


class MySql:
    def __init__(self):
        filename = "/home/pi/busTrack2k19/config.ini"        
        self.cf = ConfigParser.ConfigParser()
        self.cf.read(filename)
    def connect(self):        
        try:
            dbHost = self.cf.get("Mysql","host")                                           # MYSQL DETAILS
            dbPort = int(self.cf.get("Mysql","port"))
            dbUser = self.cf.get("Mysql","user")
            dbPassword = self.cf.get("Mysql","password")
            database = self.cf.get("Mysql","database")
            self.table = self.cf.get("Mysql","table")      
            self.db = MySQLdb.connect(dbHost,dbUser,dbPassword,database)                   # Open database connection       
            self.cursor = self.db.cursor()           
        except Exception as e:
            logging.error("Mysql connect Error - %s,' - ',%s"%(e,type(e)))

    def push(self,fields,values):
        sqlQuery = "INSERT INTO "+self.table+""
        sqlQuery += "("
        for field in fields:
            sqlQuery+=str(field)+","
        sqlQuery = sqlQuery[:-1]    
        sqlQuery+=") VALUES ("    

        for value in values:
            sqlQuery+=value+","
        sqlQuery = sqlQuery[:-1]    

        sqlQuery+=");"

        print sqlQuery

        try:

             self.cursor.execute(sqlQuery)
             self.db.commit()
             logging.info("INSERTED")    
        except (AttributeError,MySQLdb.OperationalError):
            print 'reconnect'
            st=time.time()
            logging.info("Mysql  Lost Connection ")
            self.connect()
            self.cursor.execute(sqlQuery)
            self.db.commit()
            t = str(time.time()-st)
            logging.info("Mysql Reinsert Success & %s Taken to reconnect"%(t))
        except Exception as e:
            logging.error("Mysql  Error - %s,' - ',%s"%(e,type(e)))
            with open("BackupData.xlsx",mode = 'w') as bData: 
                bDataWriter = csv.DictWriter(bData,fieldnames=columns)
                bData.writerow({fields[0]:values[0],fields[1]:values[1],fields[2]:values[2],fields[3]:values[3]})
            bData.close()    



class Rf:    
    def __init__(self,mysqlObj):
        self.ser = serial.Serial('/dev/ttyUSB0',baudrate=9600)
        self.tag = ""
        self.mysqlObj = mysqlObj
        print self.mysqlObj

    def serialRead(self):
        print "Serial Reading...."
        cardNo = ""
        sent = 0
        donereading = 0
        while True:
            try:
                n = self.ser.inWaiting()
                if n != 0:
                    data = str(self.ser.read(n))
                    cardNo+=data
                    logging.info("Detected CARD NO  - %s"%(cardNo))
                    print cardNo
                    if (cardNo in tagData.keys()):
                        print cardNo
                        logging.info ("CARD NO Existed  - %s"%(cardNo))
                        values = ["'"+str(tagData[cardNo[:6]][0])+"'","'"+str(cardNo[:6])+"'","'"+str(tagData[cardNo[:6]][1])+"'","'"+str(datetime.now().replace(microsecond=0))+"'"]
                        fields = ["busNo","tagNo","status","dateTime"]
                        self.mysqlObj.push(fields,values)
                        cardNo = ""
                    elif(len(cardNo)>6):
                        cardNo = ""
                    else:
                        logging.info("Card Not Existed  - %s"%(cardNo))
                        cardNo = ""        


                                 
            except KeyboardInterrupt as e:
                logging.error("Serial Read Error - %s,' - ',%s"%(e,type(e)))
                logging.error(" ************ PROGRAM TERMINATED ************** ")
                self.ser.close() # closes the serial connection
                sys.exit() # closes the program
                
if __name__ == '__main__':
    logging.info(" \n\n\n ****** PROGRAM STARTED **** \n\n\n ")
    with open("BackupData.xlsx",mode = 'w') as bData: 
        bDataWriter = csv.DictWriter(bData,fieldnames=columns)
        bDataWriter.writeheader()
    bData.close()
    m = MySql()
    m.connect()
    rf = Rf(m)
    rf.serialRead()



