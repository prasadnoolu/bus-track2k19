'''

    BusTrack program 
    Edited By - Rajeev Brahma
    
'''             

#!/usr/bin/env python

import logging

LOG_FILENAME = '/home/pi/busTrack2k19/LogFiles/rebootLog.log'
logging.basicConfig(filename=LOG_FILENAME,filemode = 'a',level=logging.DEBUG,format='%(asctime)s, %(levelname)s, %(message)s', datefmt='%Y-%m-%d %H:%M:%S')


logging.info("\n\n REBOOTED \n\n")
