import requests
import time
url="http://210.212.210.89:2222/bus/"
l=["912498","91275a"]
while True:
    for i in l:
        try:
            r = requests.get(url+i)
            r.raise_for_status()
        except requests.exceptions.RequestException as err:
            print ("OOps: Something Else",err)
        except requests.exceptions.HTTPError as errh:
            print ("Http Error:",errh)
        except requests.exceptions.ConnectionError as errc:
            print ("Error Connecting:",errc)
        except requests.exceptions.Timeout as errt:
            print ("Timeout Error:",errt)
    time.sleep(10)
